package ip_manager;

import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;

/**
 * Created by clientrace on 11/28/16.
 */
public class SieveAnalyzer extends ImgProcessor{

    public static final int SIZES = 0;
    public static final int COUNT = 1;


    private int state;
    private ArrayList<MatOfPoint> contours;
    private ArrayList<Double> majorAxes;
    private ArrayList<Double> minorAxes;
    private ArrayList<Integer> pixelCount;
    private Mat binary;

    public void init(){
        binary = new Mat();
        contours = new ArrayList<>();
        majorAxes = new ArrayList<>();
        minorAxes = new ArrayList<>();
        pixelCount = new ArrayList<>();
    }

    public void execute(){
        boolean done = false;
        while(!done){
            switch (state){
                case SIZES:{
                    ArrayList<RotatedRect> boundElps = new ArrayList<>();
                    ArrayList <Point> mjr1 =  new ArrayList <Point>();
                    ArrayList <Point> mjr2 = new ArrayList <Point>();
                    ArrayList <Point> mnr1 = new ArrayList <Point>();
                    ArrayList <Point> mnr2 = new ArrayList <Point>();

                    for(int i=0;i<contours.size();i++){
                        MatOfPoint2f contour2f = new MatOfPoint2f(contours.get(i).toArray());
                        if(contour2f.toArray().length<5){
                            contours.remove(i);
                            i--;
                            contour2f.release();
                            continue;
                        }

                        boundElps.add(Imgproc.fitEllipse(contour2f));
                        contour2f.release();

                        Point pnts[] = new Point[4];
                        boundElps.get(i).points(pnts);

                        mjr1.add(getMidPoint(pnts[0],pnts[3]));
                        mjr2.add(getMidPoint(pnts[1],pnts[2]));

                        mnr1.add(getMidPoint(pnts[0],pnts[1]));
                        mnr2.add(getMidPoint(pnts[2],pnts[3]));

                        majorAxes.add(getDistance(mjr1.get(i),mjr2.get(i)));
                        minorAxes.add(getDistance(mnr1.get(i),mnr2.get(i)));
                    }
                    state = COUNT;
                }
                case COUNT:{
                    for(int i=0;i<contours.size();i++){
                        Rect cRect = Imgproc.boundingRect(contours.get(i));
                        Mat subImg = binary.submat(cRect);
                        pixelCount.add(Core.countNonZero(subImg));
                    }
                    done = true;
                }
            }
        }
    }

    public void destroy(){

    }

    public double getDistance(Point p1, Point p2){
        double x1 = p1.x;
        double x2 = p2.x;
        double y1 = p1.y;
        double y2 = p2.y;
        double pp1 = Math.pow((x2-x1),2);
        double pp2 = Math.pow((y2-y1),2);
        return Math.sqrt(pp1+pp2);
    }

    public Point getMidPoint(Point p1, Point p2){
        double x1 = p1.x;
        double y1 = p1.y;
        double x2 = p2.x;
        double y2 = p2.y;
        return new Point(((x1 + x2)/2),((y1+y2)/2));
    }

    public void setContours(ArrayList<MatOfPoint> contours){
        this.contours = contours;
    }

    public ArrayList getCountours(){
        return contours;
    }

    public void setBinary(Mat binary){
        this.binary = binary;
    }

    public ArrayList<Double> getMajorAxes(){
        return majorAxes;
    }

    public ArrayList<Double> getMinorAxes(){
        return minorAxes;
    }

    public ArrayList<Integer> getPixelCount(){
        return pixelCount;
    }
}
