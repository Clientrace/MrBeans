package ip_manager;

import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by clientrace on 11/28/16.
 */
public class ShapeAnalyzer {

    public static final int INNER = 0;
    public static final int HULL = 1;
    public static final int ELLIPTICALITY = 2;

    private int state;
    private ArrayList<Double> convexHullCount;
    private ArrayList<Double> innerContourCount;
    private ArrayList<Double> ellipticality;
    private ArrayList<MatOfPoint> contours;

    public void init(){
        convexHullCount = new ArrayList<>();
        innerContourCount = new ArrayList<>();
        ellipticality = new ArrayList<>();
        contours = new ArrayList<>();
    }

    public void execute(){
        boolean done = false;
        while(!done){
            switch (state){
                case INNER:{
                    for(int i=0;i<contours.size();i++){

                    }
                }
                case HULL:{

                }
                case ELLIPTICALITY:{

                }
            }
        }
    }

    public void desktroy(){

    }

}