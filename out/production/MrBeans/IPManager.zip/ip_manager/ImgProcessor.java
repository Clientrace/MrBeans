package ip_manager;


/**
 * Created by clientrace on 11/26/16.
 */
public abstract class ImgProcessor {
    public abstract void init();
    public abstract void execute();
    public abstract void destroy();
}
